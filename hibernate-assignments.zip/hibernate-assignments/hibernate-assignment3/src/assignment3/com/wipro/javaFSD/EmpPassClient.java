package assignment3.com.wipro.javaFSD;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.Session;

public class EmpPassClient {

	public static void main(String[] args) {
		SessionFactory sessinFactory = null;
		Session session = null;
		Transaction transaction = null;
		try {
			sessinFactory = new Configuration().configure().buildSessionFactory();
			session = sessinFactory.openSession();

			Passport passport = new Passport();
			passport.setPassportNo("F74658A90");
			passport.setIssueAuthority("India");

			Employee employee = new Employee();
			employee.setEmpId(123456);
			employee.setEmpName("Srihari");
			employee.setCity("Bangalore");
			
			employee.setPassport(passport);
			
			Passport passport1 = new Passport();
			passport1.setPassportNo("9GH2456D25");
			passport1.setIssueAuthority("New York");

			Employee employee1 = new Employee();
			employee1.setEmpId(245689);
			employee1.setEmpName("Rayudu");
			employee1.setCity("USA");

			employee1.setPassport(passport1);

			transaction = session.beginTransaction();
			session.save(employee);
			session.save(employee1);
			transaction.commit();
			System.out.println("Data saved.");
		} catch (Exception e) {
			transaction.rollback();
		} finally {
			session.close();
		}
	}
}